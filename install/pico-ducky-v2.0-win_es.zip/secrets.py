secrets = {
    'ssid' : "TestAP",
    'password' : "passw1234"
}
